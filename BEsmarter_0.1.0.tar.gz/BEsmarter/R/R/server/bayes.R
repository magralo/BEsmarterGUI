output$bayes <- renderUI({
  #"Presentation content"
})